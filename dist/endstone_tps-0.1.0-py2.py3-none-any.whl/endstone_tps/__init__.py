from endstone_tps.tps import TPS

__all__ = ["TPS"]